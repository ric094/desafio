
document.getElementById("criptografarBtn").addEventListener("click", function() {
    criptografar();
});

document.getElementById("descriptografarBtn").addEventListener("click", function() {
    descriptografar();
});

document.getElementById("copiarBtn").addEventListener("click", function() {
    copiarTexto();
});

function criptografar() {
    let texto = document.getElementById("input-texto").value;
    if (texto.trim() === "") {
        exibirPlaceholder();
        return;
    }

    if (/^[a-z\s]*$/.test(texto)) {
        let textoCriptografado = texto
            .replace(/e/g, "enter")
            .replace(/i/g, "imes")
            .replace(/a/g, "ai")
            .replace(/o/g, "ober")
            .replace(/u/g, "ufat");

        document.getElementById("outputText").value = textoCriptografado;
        esconderPlaceholder();
    } else {
        alert("Por favor, insira apenas letras minúsculas sem acentos.");
    }
}

function descriptografar() {
    let texto = document.getElementById("input-texto").value;
    if (texto.trim() === "") {
        exibirPlaceholder();
        return;
    }

    let textoDescriptografado = texto
        .replace(/enter/g, "e")
        .replace(/imes/g, "i")
        .replace(/ai/g, "a")
        .replace(/ober/g, "o")
        .replace(/ufat/g, "u");

    document.getElementById("outputText").value = textoDescriptografado;
    esconderPlaceholder();
}

function copiarTexto() {
    let texto = document.getElementById("outputText");
    texto.select();
    navigator.clipboard.writeText(texto.value).then(() => {
        alert("Texto copiado para a área de transferência!");
    }).catch(err => {
        alert("Falha ao copiar o texto.");
    });
}

function exibirPlaceholder() {
    document.getElementById("placeholderImage").style.display = "block";
    document.getElementById("placeholderText").style.display = "block";
    document.getElementById("outputText").style.display = "none";
    document.getElementById("copiarBtn").style.display = "none";
}

function esconderPlaceholder() {
    document.getElementById("placeholderImage").style.display = "none";
    document.getElementById("placeholderText").style.display = "none";
    document.getElementById("outputText").style.display = "block";
    document.getElementById("copiarBtn").style.display = "block";
}

